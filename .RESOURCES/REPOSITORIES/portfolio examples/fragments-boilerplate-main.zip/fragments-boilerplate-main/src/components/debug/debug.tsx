import { StatsGl } from '@react-three/drei'

export const Debug = () => {
  return (
    <>
      <StatsGl className='fragments-boilerplate__stats' />
    </>
  )
}
