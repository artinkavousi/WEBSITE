import { Main } from './main'

export default Main
